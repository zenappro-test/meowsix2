/*MeowSixAPP || 2024-12-25 || Copyright LEE WAI KWOK(JS TRUST CONSULTANCY) HONG KONG|| license - Revised MIT.*/
import 'dart:math';
import 'dart:convert'; 
import 'dart:io';
import 'package:audio_session/audio_session.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:rxdart/rxdart.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:webview_flutter_android/webview_flutter_android.dart';
import 'package:webview_flutter_wkwebview/webview_flutter_wkwebview.dart';
import 'package:wakelock_plus/wakelock_plus.dart';
import 'package:just_audio/just_audio.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'l10n/app_localizations.dart'; 


























String zenappyr = 'Y';//Automatical value Y is provided. It uses in your APP.

String zenvlnappauth = 'Y';//You need to remove the Y if you do not accept php file for using in data file of audio choosing list and server authorization file.

List zenvlnappauthv = [[],[],[]];String zvdk = '';var zenplz = Platform.localeName.split('_')[0];Locale? zenvaddLocaln;
ThemeData? zenvthData = ThemeData.dark();//Darkorlightmode
//var zenyrthm = ThemeData.light().copyWith(colorScheme: ThemeData.light().colorScheme.copyWith(background: Colors.white,),);//ThemeData(backgroundColor: Colors.white);//Optional and you need to edit the ThemeData. 

//var zenyrthmn = ThemeData.dark().copyWith(colorScheme: ThemeData.dark().colorScheme.copyWith(background: Colors.black,),);//ThemeData(backgroundColor: Colors.black);//Same as the above item.

String zenvwebVchnnel = 'zenappja';//Automatically decide on value of APP creating parameter [9] you provided in this APP - if compatible to ZENAPPRO template, use 'zenappvwfr' instead of 'zenappja' automatically;

String zenindex = 'assets/zenindex.html';//Automatically decide on value of APP creating parameter [0] you provided in this APP;

String zenWebvwp = 'assets/zenins.html';//for this development APP use. Note - This APP webview can be triggerd by JavaScript [user interface of JS code in APP starting page] or Dart codes [user interface of flutter dart code in meow six player] to open specific URL depending on your data.

Iterable<Locale> zenvsupportLocale = <Locale>[const Locale('en'),const Locale('ja'),];//default language is controlled by l10n.yaml in root level of this APP project. APP language is decided by system language of user device OS. For adding supporting language in your APP, you need to add proper Locale value of language code to this zenvsupportLocale variable and edit related document in lib/l10n folder. e.g. adding app_ja.arb to the folder for Japanese Language. Note - The language of APP starting page [web content] is controlled by JavaScript.  If using user interface to switch language in JavaScript side and send data to dart side of Flutter, you are recommended to use specific codes, e.g. zh-tw, zh-hk

String zenappdtlan = 'en';//language using in your APP when the system language of user device is not in language supporting list. 


var zenbackbutton = Icons.arrow_back;//page back button on APP e.g. Icons.arrow_back_ios 
String zInfo = 'MEOWsixAPP';//APP Alert Title
Color plMuPagebackgroundcolor = Color(int.parse('0x3200ffff'));//It is used on APP when url of APP starting page contains zenmnbg=Y for using background picture of Playlist Menu Page.
String colorSchemepst = 'primary';//primary, secondary or tertiary for different colors
String listoddItemColorOpacity = '0.2';//Opacity between 0 - 1;
String listevenItemColorOpacity = '0.2';//Opacity between 0 - 1;
String playlistoddItemColorOpacity = '0.2';//Opacity between 0 - 1;
String playlistevenItemColorOpacity = '0.2';//Opacity between 0 - 1;
String audiolistoddItemColorOpacity = '0.1';//Opacity between 0 - 1;
String audiolistevenItemColorOpacity = '0.1';//Opacity between 0 - 1;
String zenplayvln = 'assets/jmgtb-zenpo.jpg';//e.g. zenplaybg.png or https://??????.com/zenplaybg.png It is background picture of list of playlist page of APP 
Color audiolistpagetopdivider = Color(int.parse('0xFFff0000'));//parting line of top divider on Audio List Page
Color audiotitlepopupcolor = Color(int.parse('0xFFff0000'));//background color of audio title popup on Audio Player Page. The popup is showed by clicking the title under artwork picture.
Color playerrepeatercolor = Color(int.parse('0xFF0000ff'));//color of repeat/shuffle icon of audio repeating/shuffle button on Audio Player Page
Color playerrepeatercolors = Color(int.parse('0xFFffff00'));//switching color of repeat/shuffle icon of audio repeating/shuffle button on Audio Player Page
Color playlistitlergb = Color(int.parse('0xFFff0000'));//color of title "Playlist" on Audio Player Page
Color playerbackbuttonrgb = Color(int.parse('0xCCffff00'));//background color of back button on Audio Player Page
Color audioinplayingrgb = Color(int.parse('0x32ffff00'));//background color of in-playing audio button on playlist of Audio Player Page. Opacity value is between 0-1
Color audioinplayingfontrgb = Color(int.parse('0xFFff0000'));//font color of title of in-playing audio button on playlist of Audio Player Page
Color audiofontrgb = Color(int.parse('0xFF00ffff'));//font color of title of audio button on playlist of Audio Player Page
Color audiotimergb = Color(int.parse('0xFF00ffff'));//font color of audio timing on Audio Player Page
Color audiotimebackgroundrgb = Color(int.parse('0xCC00ffff'));//background color of audio timing on Audio Player Page [particular for using background picture only] 
Color activeTrackrgb = Color(int.parse('0xFF0000ff'));//Color of audio player track in active status
Color inactiveTrackrgb = Color(int.parse('0xFFffff00'));//Color of audio player track in inactive status
Color playerbackgroundvrgba = Color(int.parse('0x1Fffff00'));//background color over background picture of Audio Player Page [for using background picture only] 


var zenvDeviceOrient = [DeviceOrientation.portraitUp];//[DeviceOrientation.portraitUp,DeviceOrientation.landscapeLeft,DeviceOrientation.landscapeRight];

double zenmninsertsp = 22;//Top padding of Playlist Menu Page 
var zenmnbg;var zennmnbg;var zenmnrgb;var zenvmnbg;String zenmnbgYv = 'Y';//Background picture of Playlist Menu Page - Auto value bases on your data
String znmwsx = '';String zsavnmwsix = '';String zenindxvlu = '';String zenptestpath = '';String mnbgzenpng = '';String zenpo = '-zenpo';String zpio = '-zpio';//for Meow Six APP use, dont remove these variables 


















int zenpushid = 1;var zenvhttp = HttpClient(); 
bool isNtInitialized = false;
late Stream<String> _zenvtokenStream;
final ValueNotifier<String?> _zvwebViewMsg = ValueNotifier<String?>(null);

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  WakelockPlus.enable();zvdk = await _zvdkvlut();
  runApp(zenvApp(zvdk:zvdk));////zenvApp.of(context)?.zeninitltn(Locale('en'));
    SystemChrome.setPreferredOrientations(zenvDeviceOrient);   ;}

_zensavedata(zenvky,zenvlu,ztyp) async {
    final SharedPreferences zenprs = await SharedPreferences.getInstance();
    if(ztyp=='' || ztyp==null)zenvlu = json.encode(zenvlu);await zenprs.setString(zenvky,zenvlu);   ;}

_zvdkvluts(zvlu) async {SharedPreferences zenprs = await SharedPreferences.getInstance();  if(zvlu!=null && zvlu!='')zvlu = zvlu.toString();await zenprs.setString('zvdark',zvlu); ;}

_zvdkvlut() async {SharedPreferences zenprs = await SharedPreferences.getInstance(); String zenrtext = ''; String? zplt = await zenprs.getString('zenaudioplist');if(zplt==null || zplt==''){try{
  if(zenappyr==''){    
  }else{zenrtext = await rootBundle.loadString('assets/zenjarydata.xml');};await zenprs.setString('zenaudioplist',zenrtext);}catch(err){;};};    String? zvdkvlu = await zenprs.getString('zvdark');if(zvdkvlu==null)zvdkvlu = '';String? zpara = await zenprs.getString('zenjappara');String? zrgbp = await zenprs.getString('zenrgbpara');if(zrgbp==null)zrgbp = '';String? zvlan = await zenprs.getString('zenvlan');if(zvlan==null)zvlan = '';;List zenpara = [];if(zpara==null){zenpara = [["","",["",""],"","","","","Y","","zenjayi","Top","",["","",""]],""];await zenprs.setString('zenjappara',json.encode(zenpara));}else{zenpara = json.decode(zpara);}; return json.encode([zvdkvlu,zenpara,zvlan,zrgbp]);  ;}//zdtdata

class zenvApp extends StatefulWidget {final String zvdk;
  zenvApp({super.key,required this.zvdk});
  @override
  State<zenvApp> createState() => _zenvAppState();
}

class _zenvAppState extends State<zenvApp> { 
  String zenvdk = ''; var zvdkvlu;List zvdkvln = [];  String zentlan = 'en';     
  @override
  void initState() { 
    super.initState();  zenvdk = this.widget.zvdk;if(zenvdk!=null){zvdkvln = json.decode(zenvdk);zentlan = zvdkvln[2];}//if(zenvdk[1][0][0].contains('zvdark=Y') && zenvdk[0]=='dark')zenvthData = ThemeData.dark();
  }
  @override
  Widget build(BuildContext context) {
  return ValueListenableBuilder<String?>(
      valueListenable: _zvwebViewMsg,
      builder: (context, ztlan, child) {
      if(ztlan=='' || ztlan=='en'){zentlan = 'en';}else if(ztlan=='ja'){zentlan = 'ja';}
      if(zentlan!=''){zenvaddLocaln = Locale(zentlan);};

      return  MaterialApp(
      debugShowCheckedModeBanner:false,theme: zenvthData,title: '',locale: zenvaddLocaln,
      localeResolutionCallback: (locale, supportedLocales) {
        if (supportedLocales.contains(locale))return locale;
        return Locale(zenappdtlan);
      },
      localizationsDelegates: [GlobalMaterialLocalizations.delegate,GlobalWidgetsLocalizations.delegate,GlobalCupertinoLocalizations.delegate,AppLocalizations.delegate,],
      supportedLocales: zenvsupportLocale,
      home:zappjWebVw(zvdk:zenvdk),
    );}); }
}

class zappjWebVw extends StatefulWidget {final String zvdk;
  const zappjWebVw({super.key,required this.zvdk});
  @override
  State<zappjWebVw> createState() => _zappjWebVw();}

class _zappjWebVw extends State<zappjWebVw> { 
  List zenvdk = [];List zenpara = []; String zvdkvlu = '';String zenvindex = ''; String zenindexhtm = '';  var zenappstart = '';String zbtnTop = 'Y';String zt = '';var zsvp;String zenindexpic = '';List zinvlu = [];var zenappd;List zdnn = [];var zvrgb;
  late final WebViewController _Zvcontroller;
  late final WebViewCookieManager cookieManager = WebViewCookieManager();
  
  @override
  void initState() { 
    super.initState();  zenvdk = json.decode(this.widget.zvdk);
      
      late final PlatformWebViewControllerCreationParams zenparams;
      if(WebViewPlatform.instance is WebKitWebViewPlatform){
        zenparams = WebKitWebViewControllerCreationParams(allowsInlineMediaPlayback: true,mediaTypesRequiringUserAction: const <PlaybackMediaTypes>{},);
      }else{zenparams = const PlatformWebViewControllerCreationParams();}

      final WebViewController _Zcontroller = WebViewController.fromPlatformCreationParams(zenparams);
      if(Platform.isAndroid){zenvpathvlu();}else{zenvpathvli();} 
      _Zcontroller..setJavaScriptMode(JavaScriptMode.unrestricted)
        ..setBackgroundColor(const Color(0x00000000))
        ..setNavigationDelegate(
          NavigationDelegate(
            onProgress: (int progress) {print('........ ($progress%)');},onPageStarted: (String url) {;},onPageFinished: (String url) {},onWebResourceError: (WebResourceError error) {},onNavigationRequest: (NavigationRequest request) {return NavigationDecision.navigate;},
          ),)..addJavaScriptChannel(
          zenvwebVchnnel,
          onMessageReceived: (JavaScriptMessage zenmsg) async {            
        var zenv = json.decode(zenmsg.message);
        if(zenv[0]=='zenvlanaltr')_zvwebViewMsg.value = zenv[1];
        },);
        if(zenindex.indexOf('assets/')==0){_Zcontroller.loadFlutterAsset(zenindex);}else{_Zcontroller.loadRequest(Uri.parse(zenindex));}

        _Zvcontroller = _Zcontroller;
  }
  
  @override
  Widget build(BuildContext context) {
    if(zenindex.contains('zenvlzn=Y')){zenindex = zenindex.replaceAll('zenvlzn=Y','zenvlzn=${zenplz}');};
    return Scaffold(
    appBar:AppBar(title: Text(AppLocalizations.of(context)!.meowsixapp),),
    body: WebViewWidget(controller:_Zvcontroller), 
    floatingActionButton: Builder(builder: (context) {   
        return FloatingActionButton.small(
          onPressed: (){},child: const Icon(Icons.menu),
          );
        }),
      floatingActionButtonLocation: FloatingActionButtonLocation.endTop,
      ); 
  }
}
Future<String> get sdpath async {final _sdpath = await getExternalStorageDirectory();return _sdpath!.path;}
Future<String> get ddpath async {final _ddpath = await getApplicationDocumentsDirectory();return _ddpath.path;}
Future<String> get sdpathi async {final _sdpath = await getTemporaryDirectory();return _sdpath.path;}
Future<String> get ddpathi async {final _ddpath = await getLibraryDirectory();return _ddpath.path;}
void zenvpathvlu() async {var sdpathv = await sdpath;var ddpathv = await ddpath;
  Directory('$sdpathv/zenjawww').create(recursive: true);  Directory('$ddpathv/zenjawww').create(recursive: true);   ;}     
void zenvpathvli() async {var sdpathv = await sdpathi;var ddpathv = await ddpathi;
  Directory('$sdpathv/zenjawww').create(recursive: true);  Directory('$ddpathv/zenjawww').create(recursive: true);   ;}

Map<String, Color> zenvToColor = {'red': Colors.red,'blue': Colors.blue,'yellow': Colors.yellow,'green': Colors.green,'purple': Colors.purple,'brown': Colors.brown,'black': Colors.black,'white': Colors.white,};


_zenscheme(colorScheme,pst,opa,ztyp){var zensvlu;
  try{if(opa is String){opa = double.parse(opa);};if(opa > 1)opa = 1;if(opa < 0)opa = 0;}catch(err){if(ztyp=='listyp-odd'){opa = 0.35;}else if(ztyp=='listyp-even'){opa = 0.55;}else if(ztyp=='playlistyp-odd'){opa = 0.05;}else if(ztyp=='playlistyp-even'){opa = 0.15;}else{opa = 0.45;};}
  if(pst=='primary'){zensvlu = colorScheme.primary.withOpacity(opa);}else if(pst=='secondary'){zensvlu = colorScheme.secondary.withOpacity(opa);}else if(pst=='tertiary'){zensvlu = colorScheme.tertiary.withOpacity(opa);}else{zensvlu = colorScheme.primary.withOpacity(opa);}
  return zensvlu;
}
_zenvLBorder(typodd,typeven,zenvlu){var zensvlu;
  try{if(typodd==typeven){zensvlu = double.parse(typodd)-1.5;if(zensvlu < 0)zensvlu = double.parse(typodd)+1.5;}else{zensvlu = (double.parse(typodd) + double.parse(typeven))/2;};if(zensvlu < 0.05)zensvlu = 0.15;}catch(err){zensvlu = zenvlu;}
  return zensvlu;
}

//var p = zenzenj();
