import java.io.File
import java.io.FileInputStream
import java.util.Properties

plugins {
    id("com.android.application")
    id("kotlin-android")
    id("dev.flutter.flutter-gradle-plugin")
}

val localProperties = Properties()
val localPropertiesFile = File("local.properties")
if (localPropertiesFile.exists()) {
    localPropertiesFile.bufferedReader(Charsets.UTF_8).use { reader ->
        localProperties.load(reader)
    }
}

var flutterVersionCode = localProperties.getProperty("flutter.versionCode") 
flutterVersionCode = flutterVersionCode ?: "1" 

var flutterVersionName = localProperties.getProperty("flutter.versionName") 
flutterVersionName = flutterVersionName ?: "1.0" 


val keystoreProperties = Properties()
val keystorePropertiesFile = rootProject.file("key.properties")
if (keystorePropertiesFile.exists()) {
    keystoreProperties.load(FileInputStream(keystorePropertiesFile))
}

android {//tryzenmeowsix.app
    namespace = "tryzenmeowsix.app"
    compileSdk = 36
    ndkVersion = "29.0.14206865"

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    sourceSets {
        getByName("main") {
        java.srcDirs("src/main/kotlin")
        }
    }

    defaultConfig {//tryzenmeowsix.app
        applicationId = "tryzenmeowsix.app"
        minSdkVersion(28)
        targetSdkVersion(flutter.targetSdkVersion)
        versionCode = flutterVersionCode.toInt()
        versionName = flutterVersionName
    }
    signingConfigs {       
        create("release") {
            keyAlias = keystoreProperties["keyAlias"] as String
            keyPassword = keystoreProperties["keyPassword"] as String
            storeFile = keystoreProperties["storeFile"]?.let { file(it) }
            storePassword = keystoreProperties["storePassword"] as String
        } 
    }
    buildTypes {//debug
        getByName("release") {
            signingConfig = signingConfigs.getByName("release")
        }
    }
}

flutter {
    source = "../.."
}

dependencies {}
